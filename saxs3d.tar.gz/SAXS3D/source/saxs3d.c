/* saxs3d v041099

   Authors:

   Dirk Walther
   Department of Cellular and Molecular Pharmacology
   University of California at San Francisco (UCSF)

   Sebastian Doniach
   Department of Physics and Applied Physics
   Stanford University



   possible optimizations:
   - better handling of distance histogram updating
   - use pointers to structures
*/

   


#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include<string.h>
#define maxPoints 27
#define offDiag 2
#define RANDMAX 2147483648.0


int LOG_SCALE;
int WEIGHT_ON_TAIL=1;



int num_o_points,measured_bins,*shuffle_list,samePos,STEEPEST=0,cycles,ADDING=0,INIT=0,VERBOSE,
  TargetMinimization,num_o_target_points,Q_scale,removeEvery=1,ConsiderFrom=0,GuinierPoints=7;
float *MeasuredProfile,*SimProfile,*MinSimProfile,MinSum=1.0e20,Rg,
  measured_x_min,measured_x_max,measured_dx,MinCorr=1.0e20,base_vector[3][3],binWidth,
  corr_weight=10.0,min_num_neighbors,MAX_S=1000.0,**distTable,
  tail_weight=3.0;

float edgeLength,edgeLengthOrig=0.0,GlobalScore=1.0e20;

char out_name[100];
float estimatedRg=0.0;

int *distHist,num_o_bins,bin_chunks,maxBin=0,FLOOD,
  BuildSphere=0,corrMaxN,SEED=0,run_time_minutes=0,
  start_time;



struct PointEl
{
  float pos[3];
  int num_o_neigh;
  int num;
};

struct PointEl *LatticePoint;

struct point_el
{
  float pos[3];
  char atom[10];
};

struct point_el *TargetPOINT;





/*---------------------------------------*/
 float distance(float *pos1, float *pos2)
/*---------------------------------------*/  
{
  return(sqrt((pos1[0]-pos2[0])*(pos1[0]-pos2[0])+
              (pos1[1]-pos2[1])*(pos1[1]-pos2[1])+
              (pos1[2]-pos2[2])*(pos1[2]-pos2[2])));

}




/*---------------------------------------*/
 float distance_2(float *pos1, float *pos2)
/*---------------------------------------*/  
{
  return((pos1[0]-pos2[0])*(pos1[0]-pos2[0])+
              (pos1[1]-pos2[1])*(pos1[1]-pos2[1])+
              (pos1[2]-pos2[2])*(pos1[2]-pos2[2]));

}





/*--------------------------*/
 void createDistTable(int n)
/*--------------------------*/
{
  int i;

  free(distTable);
  distTable=(float **)calloc(n,sizeof(float *));
  for(i=0;i<n;i++)
    distTable[i]=(float *)calloc(n,sizeof(float));


}




/*----------------------------------*/
 void setBaseVectors()
/*----------------------------------*/
{
/* base vectors according to face centered cubic lattice */
  float origin[3],d,a;

  origin[0]=origin[1]=origin[2]=0.0;
  
    
  base_vector[0][0]=edgeLength;
  base_vector[0][1]=0.0;
  base_vector[0][2]=0.0;


  base_vector[1][0]=edgeLength*cos(60.0*M_PI/180.0);
  base_vector[1][1]=edgeLength*sin(60.0*M_PI/180.0);
  base_vector[1][2]=0.0;

  base_vector[2][0]=edgeLength*cos(60.0*M_PI/180.0);
  base_vector[2][1]=tan(30.0*M_PI/180.0)*0.5*edgeLength;
  base_vector[2][2]=0.0;

  d=distance(origin,base_vector[2]);
  a=acos(d/edgeLength);

  base_vector[2][2]=edgeLength*sin(a);

}










/*----------------------------------------------------------------------*/
 void correlation(float *result, int n, float *vector1, float *vector2)
/*----------------------------------------------------------------------*/  
{
 float SP_XY,SQ_X,SQ_Y,
       sum_x=0.0,sum_y=0.0,sum_xx=0.0,sum_yy=0.0,
       sum_xy=0.0;
 

 int i,points;


 

 points=0;
 
 for(i=0;i<n;i++)
   { sum_x +=vector1[i];
     sum_y +=vector2[i];
     sum_xx+=vector1[i]*vector1[i];
     sum_yy+=vector2[i]*vector2[i];
     sum_xy+=vector1[i]*vector2[i];
     points++;
     
   }

 SP_XY=sum_xy-sum_x/(float)points*sum_y;
 SQ_X= sum_xx-sum_x/(float)points*sum_x;
 SQ_Y= sum_yy-sum_y/(float)points*sum_y;

 result[0]=SP_XY/sqrt(SQ_X*SQ_Y);/* r */
 result[1]=SP_XY/SQ_X; /* slope */
 result[2]=sum_y/(float)points-result[1]*sum_x/(float)points; /* intercept */
 
 
}







/*----------------------------*/
 void ReadXYZ(char *file_name)
/*----------------------------*/  
{
  FILE *in;
  char line[150];
  int i;
  static int model=0;
  float bond_length[10],beadRad[10];
  
 
  
  if((in=fopen(file_name,"r"))==NULL)
    {
     printf("Could not open %s\n",file_name);
     exit(0);
    }
  else
    {
      printf("Reading lattice from %s\n",file_name);
    }

  fgets(line,149,in);
  sscanf(line,"%i",&num_o_target_points);
  
  fgets(line,149,in);
  sscanf(line,"%f %f",&beadRad[model],&bond_length[model]);


  TargetPOINT=(struct point_el *)malloc(num_o_target_points*sizeof(struct point_el));
  
  for(i=0;i<num_o_target_points;i++)
  {
    
    fgets(line,149,in);
    sscanf(line,"%s %f %f %f,",TargetPOINT[i].atom,
           &TargetPOINT[i].pos[0],&TargetPOINT[i].pos[1],&TargetPOINT[i].pos[2]);
    
  }
  
  
  fclose(in);
  
}











/*----------------------------------*/
 void createLattice()
/*----------------------------------*/
{
  int i,j,k,co,ref,full=0;


  ref=0;
   LatticePoint=(struct PointEl *)calloc((20),sizeof(struct PointEl)); 
  

 
    for(i=-1;i<2;i++)
    {
      for(j=-1;j<2;j++)
      {
        for(k=-1;k<2;k++) 
        {
                   
          if((abs(i+j+k)<2) && (abs(i)+abs(j)+abs(k)>0) &&
             abs(i+j)<2 && abs(i+k)<2 && abs(j+k)<2)
          {
            num_o_points++;
            
  
            for(co=0;co<3;co++)
              LatticePoint[num_o_points].pos[co]=
                LatticePoint[ref].pos[co]+
                (float)i*base_vector[0][co]+
                (float)j*base_vector[1][co]+
                (float)k*base_vector[2][co];

            if(num_o_points==maxPoints-3)
            {
              k=3;
              j=3;
              i=3;
              
              full=1;
              break;
              
            }

            
          }
          
        } 
      }
      
    }
  
  num_o_points+=1;
  
}




/*------------------------------------------------------*/
 void neighbors()
/*------------------------------------------------------*/
{
  int i,j;
  
  float d,latt_2,cutoff;


  latt_2=edgeLength*edgeLength;
  cutoff=latt_2+edgeLength/2.0;

  for(i=0;i<num_o_points;i++)
    LatticePoint[i].num_o_neigh=0;
  
  for(i=0;i<num_o_points;i++)
  {
    for(j=i+1;j<num_o_points;j++)
    {
      d=distance_2(LatticePoint[i].pos,LatticePoint[j].pos);
      if(d<cutoff)
      {
        LatticePoint[i].num_o_neigh++;
        LatticePoint[j].num_o_neigh++;
        
      }
    }
  }
    
}

    



/*------------------------------------------------------*/
 void cut_in_half()
/*------------------------------------------------------*/
{
  int i,j,beads_added=0,co;
  float d;
  void setBaseVectors();
  
  edgeLength/=2.0;
  setBaseVectors();

  for(i=0;i<num_o_points;i++)
  {
    for(j=i+1;j<num_o_points;j++)
    {
      d=distance(LatticePoint[i].pos,LatticePoint[j].pos);
      if(d<2.0*edgeLength+.1)
      {
        beads_added++;
        
        if((num_o_points+beads_added)%50==0)
        {
          LatticePoint=(struct PointEl *)realloc(LatticePoint,(num_o_points+50+beads_added)*sizeof(struct PointEl));
          shuffle_list=(int *)realloc(shuffle_list,(num_o_points+50+beads_added)*sizeof(int));
      
        }
        
        for(co=0;co<3;co++)
        {
          LatticePoint[num_o_points+beads_added-1].pos[co]=
            LatticePoint[i].pos[co]+(LatticePoint[j].pos[co]-LatticePoint[i].pos[co])/2.0;
        }
        
      }
      
      
    }
    
  }
  num_o_points+=beads_added;
  for(i=0;i<num_o_points;i++)
    shuffle_list[i]=i;
}




/*---------------------------------------------------*/
 void calcNewDistHist(int leave_out,int npoints)
/*---------------------------------------------------*/
{
  int bin,i,j;
  float d;

  for(i=0;i<=maxBin;i++)
    distHist[i]=0;
  
  for(i=0;i<npoints;i++)
  {
    for(j=i+1;j<npoints;j++)
    {
      if(i!=leave_out && j!=leave_out)
      {
        d=distance(LatticePoint[i].pos,LatticePoint[j].pos);
        bin=(int)((d+1.0e-10)/binWidth);
        if(j!=i)
          distHist[bin]++;
      }
    }
  }
  if(leave_out<0)
    distHist[0]=npoints;
  else
    distHist[0]=npoints-1;
}




                     

/*---------------------------------------------------------------------*/
 int calcNewProfileHist(int leave_out,int point, int npoints,float *pos)
/*---------------------------------------------------------------------*/
{
  
int res,atom,aa_n1,k,i=0,j=0,AtoM,first,indx,overlap_or_too_far,bin,MaxBinLocal;
float s,ds,d,sum,**distMat,TwoPI,arg,y,first_value,minDist,sumProf,ds_2;
FILE *saxs;
int *tmpHist,*tmpRemove;






tmpHist=(int *)malloc(num_o_bins*sizeof(int));



overlap_or_too_far=0;
minDist=1.0e20;
MaxBinLocal=0;


if(leave_out<0)
{
  i=point;
  
  for(j=0;j<npoints;j++)
  {
    if(i!=leave_out && j!=leave_out && point>0)
    {
      d=distance(LatticePoint[i].pos,LatticePoint[j].pos);

      if(i!=j && d<minDist)
        minDist=d;
      
      if(d<edgeLength*0.9 && i!=j)
      {
        overlap_or_too_far=1;
        goto cont;
      }
     
      
      bin=(int)((d+1.0e-10)/binWidth);
      if(bin>maxBin)
        maxBin=bin+1;
      

   
      while(bin>=num_o_bins) /* histogram too small */
      {
	if(VERBOSE)
	  printf("dist histogram enlarged \n");
        
        distHist=(int *)realloc(distHist,num_o_bins*sizeof(int));

        tmpHist=(int *)realloc(tmpHist,num_o_bins*sizeof(int));


        
        for(k=num_o_bins;k<num_o_bins+bin_chunks;k++)
        {
          distHist[k]=0;
          tmpHist[k]=0;

        }
        num_o_bins+=bin_chunks;
      }
      
      if(bin>MaxBinLocal)
        MaxBinLocal=bin;

      
      if(i!=j)
        tmpHist[bin]+=offDiag;

      
    }
  }
  tmpHist[0]=npoints;
}







if(minDist>1.1*edgeLength && leave_out<0) 
{
  overlap_or_too_far=1;
  goto cont;
}



s=measured_x_min;
ds=measured_dx;

TwoPI=2.0*M_PI;
first=1;
indx=0;



calcNewDistHist(leave_out,npoints); 

ds_2=ds/2.0;

while(s<measured_x_max+ds_2)
{
  
  sum=0.0;
  
  for(i=1;i<=maxBin;i++) /* NOTE: it starts at i=1!!! */
  {
    
    if(i>0)
    {
      d=(float)i*binWidth;
      arg=TwoPI*s*d;
      if(s>0.0)
        sum+=(float)distHist[i]*sin(arg)/arg;
      else
        sum+=(float)distHist[i];
      
    }
    else
      sum+=distHist[i];
  }

  
 
  


  if(leave_out>=0)
    y=((float)(npoints-1)+2.0*sum); /* i=0 is added here as npoints !!! */
  else
    y=((float)npoints+2.0*sum);

  


  
  if(first)
    first_value=y;
  first=0;
  

  if(LOG_SCALE)
    SimProfile[indx++]=log(y/first_value);
  else
    SimProfile[indx++]=(y/first_value);

  
  
  s+=ds;
  
}

cont: i=1;


free(tmpHist);



return(overlap_or_too_far);

}


/*---------------------------------------------------*/
 float diffProfile(float *prof1,float *prof2,int bins)
/*---------------------------------------------------*/  
{
  float score,maxDiff,diff,sum,corr,result[3],r;
  
  int i;
  static int first=1;
  static float corrFirst=1.0,diffFirst,sumFirst;
  
  

  maxDiff=-1000.0;
  sum=0.0;
  
  
  for(i=0;i<bins;i++)
  {
    diff=sqrt((prof1[i]-prof2[i])*(prof1[i]-prof2[i]));

    
    if(WEIGHT_ON_TAIL)
      sum+=(pow(((float)i*measured_dx)/(measured_x_max),tail_weight))*diff; 
    else
      sum+=pow(1.0+(measured_x_max- (float)i*measured_dx)/(measured_x_max),tail_weight)*diff;
    
    if(diff>maxDiff)
      maxDiff=diff;
            
  }
  
  /* sum=sqrt(sum);*/


  correlation(result,corrMaxN,&prof1[0],&prof2[0]);
  r=result[0];
  corr=1.0-r;
    
  if(first)
  {
    corrFirst=corr;
    diffFirst=maxDiff;
    first=0;
    sumFirst=sum;
  }

    

  if(corr/corrFirst<MinCorr)
    MinCorr=corr/corrFirst;
  if(sum/sumFirst<MinSum)
    MinSum=sum/sumFirst;

  score=corr_weight*fabs(corr/(corrFirst))+sum/sumFirst; 
  
  return(score);
}






/*------------------*/
 void writeLattice()
/*------------------*/
{
  FILE *out;
  int i;
  char name[100];


  sprintf(name,"lattice_%s.xyz",out_name);
  out=fopen(name,"w");
  
  

  fprintf(out,"%i\n",num_o_points);
  fprintf(out,"%f %f\n",edgeLength,edgeLength);
  
  for(i=0;i<num_o_points;i++)
  {
    
    fprintf(out,"C%i %8.3f %8.3f %8.3f\n",LatticePoint[i].num,LatticePoint[i].pos[0],
            LatticePoint[i].pos[1],LatticePoint[i].pos[2]);

    
    
  }

  fclose(out);
  


}



 




/*----------------------*/
 void writeSAXSProfile()
/*----------------------*/  
{

  FILE *saxs;
  int indx;
  char name[100];
  

  sprintf(name,"saxsProfile_%s.dat",out_name);

  saxs=fopen(name,"w");
  
  for(indx=0;indx<measured_bins;indx++)
  {
    if(LOG_SCALE)
      fprintf(saxs,"%f %f\n",measured_x_min+(float)indx*measured_dx,exp(MinSimProfile[indx]));
    else
      fprintf(saxs,"%f %f\n",measured_x_min+(float)indx*measured_dx,(MinSimProfile[indx]));
    
  }
  
  fclose(saxs);
  
}



/*----------------------------------------*/
 int compare(const void *a, const void *b)
/*----------------------------------------*/
{
  const int *i=a,*j=b;
  int diff;

  diff=LatticePoint[*j].num_o_neigh-LatticePoint[*i].num_o_neigh;

  return((diff>=0)?((diff>0)? -1 : 0) : +1);
  

}



/*-----------------------------------------------*/
 int compare_reverse(const void *a, const void *b)
/*-----------------------------------------------*/
{
  const int *i=a,*j=b;
  int diff;

  diff=LatticePoint[*j].num_o_neigh-LatticePoint[*i].num_o_neigh;

  return((diff<=0)?((diff>0)? -1 : 0) : +1);
  

}



/*----------------------------------*/
 void randomize_order(int order)
/*----------------------------------*/
{
  int bead,shuffled,tmp;
  struct PointEl TmpPoint[1];
  int i,j,flipped=0,a,b;

  
  
  for(shuffled=0;shuffled<num_o_points;shuffled++)
  {
    bead=(int)((float)random()/(float)RANDMAX*(num_o_points-shuffled));
    tmp=shuffle_list[num_o_points-shuffled-1];
    
    shuffle_list[num_o_points-shuffled-1]=shuffle_list[bead]; 
    shuffle_list[bead]=tmp;
    
  }


  /* sort according to number of neighbors in ascending order */

    neighbors();


    
    if(order>0)
      qsort(shuffle_list,num_o_points,sizeof(int),compare);
    else
     qsort(shuffle_list,num_o_points,sizeof(int),compare_reverse); 



   
  }
  

/*----------------------------------*/
 void randomize_order_no_neigh()
/*----------------------------------*/
{
  int bead,shuffled,tmp;
  struct PointEl TmpPoint[1];
  int i,j,flipped=0,a,b;

  for(shuffled=0;shuffled<num_o_points;shuffled++)
  {
    bead=(int)((float)random()/(float)RANDMAX*(num_o_points-shuffled));
    tmp=shuffle_list[num_o_points-shuffled-1];
    
    shuffle_list[num_o_points-shuffled-1]=shuffle_list[bead]; 
    shuffle_list[bead]=tmp;
    
    
  }


 
  }
  
  

/*----------------------------------*/
  float getClosestToTarget(int point)
/*----------------------------------*/
    {
      int i;
      float closest=1.0e20,d;
      
      for(i=0;i<num_o_target_points;i++)
      {
        d=distance(LatticePoint[point].pos,TargetPOINT[i].pos);
        if(d<closest)
      closest=d;
        
    
  }

  return(closest);
  

}


/*----------------------------------*/
 void search()
/*----------------------------------*/
{
  int i,ii,j,k,co,ref,new_point,round=0,removed,old_removed,old_i,AdditionFailed,
    old_j,old_k,old_ref,bead_movedi,try_n_relocate,overlap,other,relocStop,indx1,indx2,indx3,
    i_min,j_min,k_min,ref_min,go_on,bead_moved,bead_min,point,refi,ok,jj,kk;
  float origin[3],d,a,score=1.0e20,newScore,minScore,minScore2,tmp_pos[3],tmp_score,
    min_pos[3],relocMinScore;
  int full=12,removedLone;
  
  
  FILE *out;
  static float FirstScore=1.0;
  static int first=1;
  char name[100];
  int num_o_points_old=0,newRelocationAttempt,newRemovelAttempt;
  int randIndex[6][3]={
    {-1,0,1},
    {0,-1,1},
    {0,1,-1},
    {1,0,-1},
    {1,-1,0},
    {-1,1,0}
  };
  
  
    
  if(SEED)
    full=12;
  
    
    
     
  sprintf(name,"scores_%s.dat",out_name);
  out=fopen(name,"w");

  
  /* set up */

  if(!INIT)
    {
      num_o_points=1;
      LatticePoint=(struct PointEl *)calloc((num_o_points+50),sizeof(struct PointEl));
      LatticePoint[0].num=num_o_points;
    }

  shuffle_list=(int *)calloc((num_o_points+50),sizeof(int));
  for(i=0;i<num_o_points+50;i++)
    shuffle_list[i]=i;
  
  score=1.0e20;




  
  if(TargetMinimization)
  {
    for(co=0;co<3;co++)
      LatticePoint[0].pos[co]=TargetPOINT[0].pos[co];
    
  }


  



  
  /* build up */
  do
  {

    cycles++;

    try_n_relocate=1;
    
    if(TargetMinimization || BuildSphere)
    {
      minScore=1.0e20;
      score=1.0e20;
      GlobalScore=1.0e20;
      
    }
    
    if(num_o_points%50==0)
    {
      LatticePoint=(struct PointEl *)realloc(LatticePoint,(num_o_points+50)*sizeof(struct PointEl));
      shuffle_list=(int *)realloc(shuffle_list,(num_o_points+50)*sizeof(int));
      for(i=0;i<num_o_points+50;i++)
        shuffle_list[i]=i;
      
    }

    
    /*
    if(cycles%20==0 && removeEvery<10)
      removeEvery++;
      */

    
    /* add a bead */
    
 
    new_point=num_o_points;
    num_o_points++;
    minScore=1.0e20;
    LatticePoint[new_point].num=new_point+1;
    ADDING=1;
    
  

    /* createDistTable(n_o_points-1); */
    
    
    for(refi=0;refi<num_o_points-1;refi++)
    {
      
     ref=shuffle_list[refi];
     if(LatticePoint[ref].num_o_neigh<full)
     {
      indx1=(int)(6.0*(float)random()/(float)RANDMAX);
      indx2=(int)(6.0*(float)random()/(float)RANDMAX);      
      indx3=(int)(6.0*(float)random()/(float)RANDMAX);                     
      
      for(ii=0;ii<3;ii++)
      {
        i=randIndex[indx1][ii];
        
        for(jj=0;jj<3;jj++)
        {
          j=randIndex[indx2][jj];
          
          for(kk=0;kk<3;kk++) 
          {
            k=randIndex[indx3][kk];
                   
            if((abs(i+j+k)<2) && (abs(i)+abs(j)+abs(k)>0) &&
               abs(i+j)<2 && abs(i+k)<2 && abs(j+k)<2)
            {
                
                for(co=0;co<3;co++)
                  LatticePoint[new_point].pos[co]=
                    LatticePoint[ref].pos[co]+
                    (float)i*base_vector[0][co]+
                    (float)j*base_vector[1][co]+
                    (float)k*base_vector[2][co];

                

                
                if(!calcNewProfileHist(-1,new_point,num_o_points,NULL))
                {
                  if(!TargetMinimization && !BuildSphere)
                    newScore=diffProfile(SimProfile,MeasuredProfile,measured_bins);
                  else
                  {
                    if(!BuildSphere)
                    {
                      newScore=getClosestToTarget(new_point);
                      
                      if(newScore>3.0 /*edgeLength/2.0*/)
                        newScore=minScore+10000.0;
                    } else {
                      newScore=distance(LatticePoint[new_point].pos,LatticePoint[0].pos);
                      
                    }
                    
                    
                  }
                  
                  
                }
                else
                    newScore=minScore+1000.0;

                
                if(STEEPEST)
                  tmp_score=minScore;
                else
                  tmp_score=score;
                
                
                if(newScore<tmp_score ||  newScore<minScore)
                {
                  minScore=newScore; 
                                    
                  for(co=0;co<3;co++)
                    min_pos[co]=LatticePoint[new_point].pos[co];
                 
                  
                  for(i=0;i<measured_bins;i++)
                    MinSimProfile[i]=SimProfile[i];

                  if(!STEEPEST && newScore<score)
                  {
                    refi=num_o_points;
                    ii=3;
                    jj=3;
                    kk=3;
                    
                  }
                  
                }
              
            }
          } 
        }
      }
    } 
    }
    if(VERBOSE)
      printf("+ %5i min new score=%.3e  global score=%.3e corr=%.3e rms=%.3e\n",
	     num_o_points,minScore,GlobalScore,MinCorr,MinSum);

    

    if(minScore-score<0.0)
    {
      for(co=0;co<3;co++)
        LatticePoint[new_point].pos[co]=min_pos[co];
      
      go_on=1;
      try_n_relocate=0;
      
      score=minScore;
      AdditionFailed=0;
      
    }
    else
      AdditionFailed=1;
    
    
    if(FLOOD==0 || AdditionFailed )
    {
    if(num_o_points>2 && !TargetMinimization) 
    {

      /* remove a bead */

      do
      {

	
        minScore2=1.0e20;
        if(minScore>GlobalScore && num_o_points>3)
	  {
	    num_o_points--;
	  }
        
	if(!STEEPEST)
	  randomize_order(1); 
	
	

	for(ii=0;ii<num_o_points;ii++)
	  {
	    i=shuffle_list[ii];

	    if(cycles%removeEvery==0 || AdditionFailed)
	      {

		if(!calcNewProfileHist(i,i,num_o_points,LatticePoint[i].pos))  
		  newScore=diffProfile(SimProfile,MeasuredProfile,measured_bins);
		else
		  newScore=minScore2+1000.0;
		
	

		if(STEEPEST)
		  tmp_score=minScore2;
		else
		  tmp_score=score;
		
		
		if((newScore<tmp_score ||  newScore<minScore2))
		  {
		    
		    minScore2=newScore;
		    removed=i;
		    
		    
		    
		    for(k=0;k<measured_bins;k++)
		      MinSimProfile[k]=SimProfile[k];
		    
		    
		    if(!STEEPEST && newScore<score)
		      ii=num_o_points;
		    
		    
		    
		  }
		
		/* always remove if bead has no neighbor */
		removedLone=0;
		if(LatticePoint[i].num_o_neigh==0 && AdditionFailed)
		  {
		    minScore2=newScore;
		    removed=i;
				  
		    for(k=0;k<measured_bins;k++)
		      MinSimProfile[k]=SimProfile[k];
		    
		    removedLone=1;
		    
		    ii=num_o_points; 
		  }
	
		
	      } 
	  }

      
	
      
	
	
	
	if(minScore2<score || removedLone)
	  {
	    
	    writeLattice();
	    writeSAXSProfile();
	    
	    go_on=1;
	    if(VERBOSE)
	      printf("- %5i removed, new Score %e\n",removed+1,minScore2);
	    old_removed=removed;
	    minScore=minScore2;
	    score=minScore2;
	    
	    for(i=removed;i<num_o_points-1;i++)
	      {
		for(co=0;co<3;co++)
		  LatticePoint[i].pos[co]=LatticePoint[i+1].pos[co];
		
	      }
	    num_o_points--;
	    for(i=0;i<num_o_points;i++)
	      shuffle_list[i]=i;
	    
	    
	    
	    try_n_relocate=0; /* =1 always relocate */
	    
	    newRemovelAttempt=0;
	    
	    
	  }
	else{
	  newRemovelAttempt=0;
	  
	  /* go_on=0; */
	  /* try_n_relocate=0; */
	  if(cycles%removeEvery==0 && VERBOSE)
	    printf("- removing failed with score %.3e\n",minScore2);
	}

      }
      while(newRemovelAttempt);
      
      
      
      
      
      
      
      
      
      
      /* relocate beads  */
      
      if(try_n_relocate && full>=12) 
	{
	  start_time=time(0);
	  
	  do
	    {
	      relocStop=0;
	      if(!STEEPEST)
		randomize_order(1);
	      
	      
	      minScore2=1.0e20;
	      
	      
	      for(bead_movedi=0;bead_movedi<new_point-1;bead_movedi++) 
		{

		  
		  if((time(0)-start_time)/60>run_time_minutes && run_time_minutes>0)
		    {
		      
		      printf("exited because exceeding run time minutes\n");
		      return;
		    }


		  relocMinScore=1.0e20;
		  
		  bead_moved=shuffle_list[bead_movedi];
		  if(LatticePoint[bead_moved].num_o_neigh>=0)
		    {
		      for(co=0;co<3;co++)
			tmp_pos[co]=LatticePoint[bead_moved].pos[co];
		      
		      /*if(((bead_movedi*100)/(new_point-1))%10==0)*/
		      {
			if(VERBOSE)
			  printf(".");
			fflush(stdout);
			
		      }
		      for(refi=0;refi<num_o_points;refi++)
			{
			  ref=shuffle_list[refi];

			  
			  if(relocStop==0 && LatticePoint[ref].num_o_neigh<full)
			    {
			      
			     

			      indx1=(int)(6.0*(float)random()/(float)RANDMAX);
			      indx2=(int)(6.0*(float)random()/(float)RANDMAX);      
			      indx3=(int)(6.0*(float)random()/(float)RANDMAX);                     
			      
			      for(ii=0;ii<3;ii++)
				{
				  i=randIndex[indx1][ii];
				  
				  for(jj=0;jj<3;jj++)
				    {
				      j=randIndex[indx2][jj];
				      
				      for(kk=0;kk<3;kk++) 
					{
					  k=randIndex[indx3][kk];
					  
					  
					  
					  if((abs(i+j+k)<2) && (abs(i)+abs(j)+abs(k)>0) &&
					     abs(i+j)<2 && abs(i+k)<2 && abs(j+k)<2)
					    {
					      
					      for(co=0;co<3;co++)
						LatticePoint[bead_moved].pos[co]=
						  LatticePoint[ref].pos[co]+
						  (float)i*base_vector[0][co]+
						  (float)j*base_vector[1][co]+
						  (float)k*base_vector[2][co];
					      
					      overlap=0;
					      
					      for(other=0;other<num_o_points;other++)
						{
						  d=distance_2(LatticePoint[bead_moved].pos,LatticePoint[other].pos);
						  if(d<0.1 && other!=bead_moved)
						    overlap=1;
						}
					      
					      if(distance_2(LatticePoint[bead_moved].pos,tmp_pos)<0.1)
						overlap=1;
					      
					      
					      if(!overlap)
						{
						  
						  
						  if(!calcNewProfileHist(-1,bead_moved,num_o_points,NULL))
						    newScore=diffProfile(SimProfile,MeasuredProfile,measured_bins);
						  else
						    newScore=minScore2+1000.0;
						  
						  if(STEEPEST)
						    tmp_score=minScore2;
						  else
						    tmp_score=score;                  
						  
						  if(newScore<tmp_score || newScore<minScore2)
						    {
						      minScore2=newScore;
						      i_min=i;
						      j_min=j;
						      k_min=k;
						      ref_min=ref;
						      
						      for(co=0;co<3;co++)
							min_pos[co]=LatticePoint[bead_moved].pos[co];
						      
						      
						      bead_min=bead_moved;
						      
						      
						      
						      if(newScore<score)
							{
							  
							  for(i=0;i<measured_bins;i++)
							    MinSimProfile[i]=SimProfile[i];
							  
							  if(!STEEPEST && newScore<score)
							    {
							      bead_movedi=num_o_points;
							      relocStop=1;
							      ii=3;
							      jj=3;
							      kk=3;
							      
							      
							    }
							}
						    }
						  if(newScore<relocMinScore)
						    relocMinScore=newScore;
						  
						}
					    }
					}
				    } 
				}
			    }
			}
		      
		      
		      for(co=0;co<3;co++)
			LatticePoint[bead_moved].pos[co]=tmp_pos[co];
		      
		    }
		}
	      
	      
	      
	      
	      
	      
	      
	      if(minScore2<score) 
		{
		  for(co=0;co<3;co++)
		    LatticePoint[bead_min].pos[co]=min_pos[co];
		  if(VERBOSE)
		    printf("\n= %5i relocated with score=%.3e\n",bead_min+1,minScore2);
		  
		  go_on=1;
		  score=minScore2;
		  newRelocationAttempt=0;
		  
		  
		} else {
		  newRelocationAttempt=0;
		  
		  if(edgeLengthOrig/edgeLength<0.0)
		    {
		      
		      edgeLength/=2.0;
		      setBaseVectors();
		      go_on=1;
		      num_o_points--;
		      
		      
		      STEEPEST=0;
		      if(VERBOSE)
			printf("STEEPEST set to zero\n");
		      
		      if(VERBOSE)
			{
			  printf("===========================================================\n");
			  printf("base vectors halved (%f) at score %10.5f and %i beads\n",edgeLength,score,num_o_points);
			  printf("===========================================================\n");
			}
			  
		    } else {
		      go_on=1;
		      /*
			if(minScore2<minScore)
			num_o_points--;
		      */
		    }
		}
	      
	    }
	  while(newRelocationAttempt);
	}
      
    }
    }
    
    if(first)
      FirstScore=score;
    first=0;
    
    
    if(score<GlobalScore || (TargetMinimization && minScore<edgeLength/2.0)
       || removedLone)
      {
	
	
	
	fprintf(out,"%i %f\n",num_o_points,score/FirstScore);
	fflush(out);
	writeLattice();
	writeSAXSProfile();
	GlobalScore=score;
	/*
	  calcNewProfileHist(-1,-1,num_o_points,NULL);
	  corr_weight=MinSum/MinCorr;
	  score=diffProfile(SimProfile,MeasuredProfile,measured_bins);
	  GlobalScore=score;
	*/
      } else {
	if(edgeLengthOrig/edgeLength<0.0)
	  {
	    cut_in_half();
	    if(!calcNewProfileHist(-1,-1,num_o_points,NULL))
	      newScore=diffProfile(SimProfile,MeasuredProfile,measured_bins);
	    score=newScore;
	    GlobalScore=score;
	    if(VERBOSE)
	      {
		printf("===========================================================\n");
		printf("base vectors halved (%f) with new score %10.5f and %i beads\n",edgeLength,score,num_o_points);
		printf("===========================================================\n");
	      }
	    writeLattice();
	    
	    
	    
	  } else {
	    if(full<12)
	      {
		go_on=1;
		/*full=12; */
		full++;
		
		STEEPEST=0;
		FLOOD=0;
		
		if(VERBOSE)
		  printf("\n<<<<<<<<<<< full = %i >>>>>>>>>>>\n\n",full);
		
		
	      } else {
		
		TargetMinimization=0;
		if(!SEED)
		  exit(0);
		
	      }
	  }
      }
    if(!STEEPEST)
      randomize_order(1);  
   
    
  }
  while(go_on); 
  
  fclose(out);
  
}

/*-----------------------------------*/
char *CheckEquidistProfile(char *file)
/*-----------------------------------*/
{
  static char file_name[400];
  char line[200];
  double x_value[10000],y_value[10000],x_old,dx_old,dx,first_x,last_x,x;
  int i=0,N,bin,j;
  FILE *in,*out;
  double closest_x,d;
  int closest_x_idx;


  sprintf(file_name,"%s",file);

  if((in=fopen(file,"r"))==NULL)
    {
      printf("Cannot not open %s\n",file);
      exit(0);
    }
  else
    {
      printf("Reading profile from %s\n",file);
      printf("checking for equidistance in x-coordinate\n",file);
    }


  while(!feof(in))
    {
     fgets(line,90,in);
    
     if(line[0]!='#')
       {
	 
	 if(feof(in))
	   break; 

 
	 sscanf(line,"%lf %lf",&x_value[i],&y_value[i]);
	 
	 if(i==0)
	   first_x=x_value[i];
	 
	 last_x=x_value[i];
	 
	 /*printf("%f\t%f %f\n",x_value[i]-x_old,x_old,x_value[i]);*/

	 x_old=x_value[i];

	 i++;


	 if(i>9999)
	   {
	     printf("can only handle up to 10000 points\n");
	     exit(0);
	   }
       }
    }
  fclose(in);
  
  N=i;
  dx=(last_x-first_x)/(double)(i-1);




  sprintf(file_name,"%s.equi",file);

  printf("writing profile to file %s with equi-dist x-values\n",file_name);
  out=fopen(file_name,"w");
  fprintf(out,"%lf %lf\n",first_x,y_value[0]);


  for(i=1;i<N;i++)
  {
   closest_x=2.0*last_x; 
    x=first_x+(double)i*dx;
    for(j=0;j<N;j++)
    {
      d=fabs(x-x_value[j]);
      if(d<closest_x)
       {
        closest_x=d;
        closest_x_idx=j;
       }
    } 
    fprintf(out,"%lf %lf\n",x,y_value[closest_x_idx]);
    

  }
  fclose(out);

  
  


  return(file_name);
}



/*---------------------------------*/
 void ReadProfile(char *file)
/*---------------------------------*/
{
  FILE *in,*out;
  char line[100];
  float x,y;
  
  int first=1,i;
  void extrapolate();
  
  
  
  if((in=fopen(file,"r"))==NULL)
  {
    printf("Cannot not open %s\n",file);
    exit(0);
  }
  else
    {
      printf("Reading profile from %s\n",file);
    }
  
 
  

  MeasuredProfile=(float *)malloc(sizeof(float));
 
    
  while(!feof(in))
  {
    
    fgets(line,100,in);

    if(line[0]!='#')
    {
     
      
      sscanf(line,"%f %f",&x,&y);


      if(Q_scale)
        x/=(2.0*M_PI);
      
      if(feof(in))
        break;

      
      if(first)
        measured_x_min=x;
      else
        measured_x_max=x;
      first=0;

      MeasuredProfile[measured_bins]=y;

      
      measured_bins++;
      MeasuredProfile=(float *)realloc((float *)MeasuredProfile,
                                      (measured_bins+1)*sizeof(float));
      
     if(x>MAX_S)
       break;
    }
  }

  measured_dx=(measured_x_max-measured_x_min)/(float)(measured_bins-1);
  SimProfile=(float *)malloc((measured_bins+1)*sizeof(float));
  MinSimProfile=(float *)malloc((measured_bins+1)*sizeof(float));


  

 

 
  if((int)(measured_x_min/measured_dx)>0)
    extrapolate(file);

 
  if(LOG_SCALE)
    {
    for(i=measured_bins-1;i>=0;i--)
	MeasuredProfile[i]=log(MeasuredProfile[i]);
    }
 
  corrMaxN=measured_bins-1;

  if(VERBOSE)
    printf("Correlation up to %i s=%f\n",corrMaxN,(float)corrMaxN*measured_dx);
  


}




/*--------------------------*/
 float estimateRg()
/*--------------------------*/
{
  float R;
  int n,i,points,j;
  float mean_slope,*tmp,slope,intercept,xx[50],logy[50],result[3],x,y,value;
  

  
  n=(int)(measured_x_min/measured_dx);
  tmp=(float *)malloc((n+1)*sizeof(float));

  
  points=GuinierPoints; /* Guinier fit */
  for(i=0;i<points;i++)
  {
    xx[i]=measured_x_min+(float)i*measured_dx;
    xx[i]*=xx[i];
    logy[i]=log(MeasuredProfile[i]);
    
    /*printf("%f %f     %i %f %f\n",measured_x_min,measured_dx,i,xx[i],logy[i]);*/

  }
  correlation(result,points,xx,logy);

  slope=result[1];
  intercept=result[2];

  R=sqrt(-3.0/4.0/M_PI/M_PI*slope);
  
  return(R);
}




/*--------------------------*/
 void extrapolate(char *name)
/*--------------------------*/
{
  int n,i,points,j;
  float mean_slope,*tmp,slope,intercept,xx[50],logy[50],result[3],x,y,value;
  FILE *f;
  char newName[200];
  float mean_x=0.0,mean_y=0.0;

  sprintf(newName,"%s_new",name);

  
 
 
  printf("\nextrapolating profile to s=0\n");
  printf("writing profile to file: %s\n",newName);
 

  f=fopen(newName,"w");
  
  n=(int)(measured_x_min/measured_dx);
  tmp=(float *)malloc((n+1)*sizeof(float));

  ConsiderFrom=0;
  
  
  points=GuinierPoints; /* Guinier fit */
  if(points<3)
    {
      printf("two few points in Guinier fit.\n");
      exit(0);
    }
  for(i=0;i<points;i++)
  {
    xx[i]=measured_x_min+(float)i*measured_dx;
    xx[i]*=xx[i];
    logy[i]=log(MeasuredProfile[i]);

    mean_x+=xx[i];
    mean_y+=logy[i];
    
  }
  correlation(result,points,xx,logy);
  mean_x/=points;
  mean_y/=points;
  
  
  slope=result[1];
  intercept=result[2];
  
  
  /*
  for(i=0;i<points;i++)
    mean_slope+=(MeasuredProfile[i]-MeasuredProfile[i+1])/measured_dx;
  mean_slope/=(float)points;
  */
  /*printf("%f %f\n",slope,intercept);*/
  if(estimatedRg>1.0)
    {
      slope=-4.0/3.0*M_PI*M_PI*estimatedRg*estimatedRg;
      intercept=mean_y-slope*mean_x;

    }
  /*printf("%f %f %f\n",slope,intercept,estimatedRg);*/
  
  tmp[0]=MeasuredProfile[0];
  
  for(i=1;i<=n;i++)
  {
    x=measured_x_min-(float)i*measured_dx;
    y=slope*(x*x)+intercept;
    tmp[i]=exp(y);
  }

  MeasuredProfile=(float *)realloc((float *)MeasuredProfile,
                                   (measured_bins+2+n)*sizeof(float));

  j=0;

  for(i=measured_bins-1;i>=0;i--)
    MeasuredProfile[n+i]=MeasuredProfile[i];

   
  
  measured_bins+=n;
  measured_x_min-=(float)n*measured_dx;
  
  j=0;
  for(i=n;i>=0;i--)
    MeasuredProfile[j++]=tmp[i];
  

  value=MeasuredProfile[0];
  
  for(i=0;i<measured_bins;i++)
  {
    MeasuredProfile[i]/=value;
    fprintf(f,"%f %f\n",measured_x_min+(float)i*measured_dx,
            MeasuredProfile[i]);

    
  }
  
  free(SimProfile);
  free(MinSimProfile);
  
  SimProfile=(float *)malloc((measured_bins+1)*sizeof(float));
  MinSimProfile=(float *)malloc((measured_bins+1)*sizeof(float));
  free(tmp);
  fclose(f);
    
}



/*------------------------*/
 void addTail(char *name)
/*------------------------*/
{

  int i,points_to_add=0;
  float s,mean_I,value;
  char newName[200];
  FILE *f;
  
  mean_I=(MeasuredProfile[measured_bins-1]+
          MeasuredProfile[measured_bins-2]+
          MeasuredProfile[measured_bins-3])/3.0;
  
  
  s=(float)(measured_bins)*measured_dx;
  points_to_add=(int)((0.12-s)/measured_dx);
  MeasuredProfile=(float *)realloc((float *)MeasuredProfile,
                                     (measured_bins+points_to_add+1)*sizeof(float));
  for(i=0;i<points_to_add;i++)
  {
    s+=measured_dx;
    MeasuredProfile[measured_bins+i]=
      exp(log(mean_I)-24.33074*(float)(i+1)*measured_dx);
    measured_x_max=s;
    
  }

  measured_bins+=points_to_add;

  sprintf(newName,"%s_new",name);
  
  printf("\nadding tail\n");
  printf("writing profile to file: %s\n",newName);
  
  f=fopen(newName,"w");
  value=MeasuredProfile[0];
  for(i=0;i<measured_bins;i++)
  {
    MeasuredProfile[i]/=value;
    fprintf(f,"%f %f\n",measured_x_min+(float)i*measured_dx,
            MeasuredProfile[i]);

    
  }
  fclose(f);
    
  free(SimProfile);
  free(MinSimProfile);
  
  SimProfile=(float *)malloc((measured_bins+1)*sizeof(float));
  MinSimProfile=(float *)malloc((measured_bins+1)*sizeof(float)); 
}






/*------------------------*/
 void setupHistogram()
/*------------------------*/
{
  
  binWidth=edgeLength/20.0;
  bin_chunks=50.0*edgeLength/binWidth;

  distHist=(int *)calloc(bin_chunks,sizeof(int));


  num_o_bins=bin_chunks;
  
}






/*------------------------------*/
 void initializeModel(char *name)
/*------------------------------*/
{
  FILE *in;
  char line[100],word[100];
  int num,i;
  float l1,l2;

  num=0;
  printf("\nread initial model from %s\n",name);
  if((in=fopen(name,"r"))==NULL)
    {
      printf("Cannot open %s\n",name);
      exit(0);
    }
  fscanf(in,"%i",&num_o_points);
  fscanf(in,"%f %f",&l1,&l2);
  
  
  LatticePoint=(struct PointEl *)calloc((num_o_points+50),sizeof(struct PointEl));
  
  for(i=0;i<num_o_points;i++)
    {
      
      fscanf(in,"%s %f %f %f",word,&LatticePoint[i].pos[0],
	     &LatticePoint[i].pos[1], &LatticePoint[i].pos[2]);
      LatticePoint[i].num=i;
      
    }
  

    



}









main(int argc, char **argv)
{

  char options[500],*p;
  int i;
  char xyz_name[100],init_model[100],*new_file;
  int TAIL;
 
  
  if(argc<2)
    {
      printf("\nsaxs3d v041000\nAuthors: Dirk Walther, UCSF & Sebastian Doniach, Stanford\n");
      printf("walther@cmpharm.ucsf.edu, doniach@drizzle.stanford.edu\n");
      printf("Reference: Reconstruction of low resolution three-dimensional maps\n");
      printf("from one-dimensional small angle x-ray solution scattering data for biomolecules.\n");
      printf("Walther, D, Cohen FE & Doniach S\n");
      printf("submitted to J Appl Crystallogr\n\n");
      printf("usage: command <saxs_profile_file> -l <lattice spacing> -i <initial xyz-file> -rm_mod <mod>\n\t-out <id_string> -flood -steepest -q -max_s <s_max> -xyz <target xyz-file>\n\t-rw <weight> -tw <weight> -g <npoints> -rg <estimated Rg> -v -k <minutes>\n\n");
      printf("\t -l\tlattice spacing in Angstrom\n");
      printf("\t -i\tstart from a given xyz-structure\n");
      printf("\t -rm_mod\tremoval-attempt every cycle%%mod==0, default:mod=1\n");
      printf("\t -out\twrite output to files containing id_string, default: id_string=test\n");
      printf("\t\t models are continueously written to lattice_id_string.xyz\n");
      printf("\t\t profiles are continueously written to saxsProfile_id_string.dat\n");
      printf("\t\t profile fit-scores are continueously written to scores_id_string.dat\n");
	     
      printf("\t -flood\tkeep adding beads until no improvement can be made, then remove\n"); 
	/* printf("\t -S\tminimize in logarighmic scale\n"); */
      printf("\t -steepest\tfind the steepest descent move (i.e. exhaustive search, slow!\n");
      printf("\t -q\tinput saxsfile is in q-scale (q=2Pi s)\n");
      printf("\t -max_s\tchop off profile beyond s_max\n");
      printf("\t -xyz\tfill a lattice to match a target xyz-structure (no minimization)\n");
      printf("\t -rw\tweight on correlation component of scoring function, default weight=10.0\n");
      printf("\t -tw\tweight on deviations in the tail of the profile, default weight=3.0\n");
      printf("\t -g\t<npoints> points to consider in Guinier fit, default: npoints=7\n"); 
      printf("\t -rg\t<Rg> slope of Guinier fit according to estimated Rg\n"); 
      printf("\t -v\tverbose output to the screen\n"); 
      printf("\t -k <minutes>\tterminate after <minutes> of futile relocation attempts\n"); 
      exit(0);
    }

  start_time=time(0);

  sprintf(options,"");
  
  for(i=1;i<argc;i++)
    sprintf(options,"%s %s",options,argv[i]);

  if(strstr(options,"-flood"))
    FLOOD=1;
  else
    FLOOD=0;
  
  
  if(strstr(options," -S"))
  {
    LOG_SCALE=1;
    WEIGHT_ON_TAIL=0;
    printf("minimization in log-scale, Weight on Tail = 0\n");
  } else {
    LOG_SCALE=0;
    printf("minimization in linear-scale\n");
  }
  if((p=strstr(options," -l"))!=NULL)
  {
    sscanf(p+3,"%f",&edgeLengthOrig);
    printf("edge length = %f\n",edgeLengthOrig);
  }
  
 if((p=strstr(options," -max_s"))!=NULL)
  {
    sscanf(p+7,"%f",&MAX_S);
  }

  if(strstr(options,"-tail"))
  {
    TAIL=1;
  }
  else
    TAIL=0;

  if((p=strstr(options," -rm_mod"))!=NULL)
    {
      sscanf(p+8,"%i",&removeEvery);
    }
  else
    removeEvery=1;

  if((p=strstr(options," -rw"))!=NULL)
    {
      sscanf(p+4,"%f",&corr_weight);
    }

  if((p=strstr(options," -tw"))!=NULL)
    {
      sscanf(p+4,"%f",&tail_weight);
    }  

  if((p=strstr(options," -k"))!=NULL)
    {
      sscanf(p+3,"%i",&run_time_minutes);
      printf("max run time %i min\n",run_time_minutes);
     
    }
  


  if(strstr(options,"-seed"))
  {
    SEED=1;
  }
  else
    SEED=0; 
   
  
  if(strstr(options,"-sphere"))
  {
    BuildSphere=1;
    STEEPEST=1;
    
  }

  if(strstr(options," -q"))
    Q_scale=1;
  else
    Q_scale=0;


  
  if(strstr(options,"-steepest"))
  {
    STEEPEST=1;
  }

  if(strstr(options," -v"))
  {
    VERBOSE=1;
  }
  else VERBOSE=0;


  if(strstr(options,"-out"))
  {
    sscanf((char *)(strstr(options,"-out")+4),"%s",out_name);
  }
  else
    sprintf(out_name,"test");



  
  if(strstr(options,"-xyz"))
  {
    sscanf((char *)(strstr(options,"-xyz")+4),"%s",xyz_name);
    ReadXYZ(xyz_name);
    TargetMinimization=1;
    
  }
  else
    TargetMinimization=0;

  if((p=strstr(options," -i"))!=NULL)
    {
      INIT=1;
      sscanf(p+3,"%s",init_model);
      initializeModel(init_model);
    }
  
  if((p=strstr(options," -g"))!=NULL)
      sscanf(p+3,"%i",&GuinierPoints);
  
  
  if((p=strstr(options," -rg"))!=NULL)
      sscanf(p+4,"%f",&estimatedRg);
    

  srandom(time(0));
 

  new_file=CheckEquidistProfile(argv[1]);
  ReadProfile(new_file);
  
  Rg=estimateRg();
  printf("estimated Rg: %f\n",Rg);
  
  if(TAIL) 
    addTail(argv[1]);
  
  


  if(edgeLengthOrig<0.1)
  {
    edgeLengthOrig=Rg/3.0;
    printf("edge length = %f %f\n",edgeLengthOrig,Rg);
  }

    
  edgeLength=edgeLengthOrig;
  

  printf("STEEPEST set to %i\n",STEEPEST);
  
  setupHistogram();
  setBaseVectors();
  /*
  createLattice();
  writeLattice();
  */
 
  search(); 

}
