/***********************************************
 * pdb2xyz_saxs
 * Author: Dirk Walther, UCSF
 * converts pdb to xyz and calulates Debye scattering profile
 * call without parameters for instructions
 ***********************************************/



#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "vector.c"
#include "rotate_2.c"


#define X 0
#define Y 1
#define Z 2 



#define maxchains 50
#define sphere 11.0 




struct Nucl_Acid_Atom_Struct
{ int base_code; 
  int atom_number;
  int drawing_neighbour;
  int read;
};

struct Nucl_Acid_Atom_Struct *Nucl_Acid_Atom;

float *Nucl_Acid_Atom_pos,RG;

int trace_start[maxchains],NoBfact;

char  pdb_name[150], dssp_name[150], chain_id, **HeteroCode,selectedAA='-',selectedSECTYPE='-',
      path1[150]={""}, path2[160]={""},title[200];


int   number_o_residues,CHAIN_RES=0,Num_o_Chains,Num_o_Chain_coord[maxchains],
      chain_old,number_o_nucl_acid_atoms,DetermineHelixPosition;

int   GRAPHICS,CBETA,CALPHA,MAIN_CHAIN,NUMBER_O_DRAW_POINTS,SLAB,LABEL,
      SEC,NOTRACE,HETERO,VDW,Z_BUFF=0;
      

float *ATOMS,*radii, area, *area_list,*volume;
int    n_o_ATOMS,N_o_surf_points =1000; 
 

 
float *Surface_dots,*s_dots,*HeteroAtoms;
int    *Phobicity; 


int     npoints,nhydrovec,CBETA,loop_points, TOTAL_RES,total_aa=0,num_o_het_atoms,*Water,*dense,
        SIDE_CHAINS_SHORT,SIDE_CHAINS,comp[21],number[3][20],*HeteroAtomType;

FILE    *PDB, *DSSP,*subset, *OUT, *HIST_FILE, *MIN_CLOSEST, *MIN_CLOSEST_2,*CA_TRACE,
        *DENSITY_FILE,*COMPOS_FILE;

fpos_t  FILE_POSITION_PDB, FILE_POSITION_DSSP;
float   top_x=0, bottom_x=0, top_y=0,  sum_twist[3][20],sum_twist_squared[3][20],
        density_o_protein,
        bottom_y=0, top_z=0, bottom_z=0,center_o_protein[3];
long    POSITION;
 
 



int     hist[25][200],SURFACE,NUMBER_O_SURF_DOTS=0,PHIL; 
float   GRID=.5,radius_o_gyration,frac_phil,frac_phob,frac_phobic_surface,frac_philic_surface,
        frac_phil_surf,frac_phob_surf,resolution; 


 


 







/*--------------------------------------------*/
 void SAXS_DISTHIST(char *pdb_name,char *name)
/*--------------------------------------------*/
{
int res,atom,aa_n1,i=0,j=0,AtoM,first,startAt,add,*distHist,nbins,N,atoms,co,CA_atoms=0;
float s,ds,d,sum,**distMat,TwoPI,arg,y,first_value,binW=0.05,min[3],max[3];
FILE *saxs,*pdb,*xyz;
char line[200],firstWord[20];
char word[20],number[10],atom_id[20],residue[20],xyz_name[200],saxs_name[200];
int *isCa;

  for(co=0;co<3;co++)
  {
    min[co]=100000.0;
    max[co]=-100000.0;
  }


  pdb=fopen(pdb_name,"r");


  


ATOMS  = (float *)calloc(3*1000,sizeof(float));
isCa=(int *)calloc(1000,sizeof(int));

atoms=0;

while(!feof(pdb))
{
  if(atoms%1000==0)
    {
      ATOMS=(float *)realloc(ATOMS,(3*(atoms+1000))*sizeof(float));
      isCa=(int *)realloc(isCa,(atoms+1000)*sizeof(int));
    }
  
  fgets(line,85,pdb);

  sscanf(&line[13],"%s",atom_id);
  
  sprintf(firstWord,"");
  for(i=0;i<8;i++)
    sprintf(firstWord,"%s%c",firstWord,line[i]);
  
  if(strstr(firstWord,"ENDMDL"))
    break;

  
  if(line[13]!='H' && ((chain_id ==95) || (line[21]== chain_id)))
  {
    if(strstr(firstWord,"ATOM")!=NULL || (strstr(firstWord,"HETATM")!=NULL && HETERO))
  {
    
 if(line[16]==' ' || line[16]=='A')
    {
    
    if(strstr(line,"HOH")==NULL)
    {
         
    sscanf(&line[30],"%f %f %f",&ATOMS[3*atoms],&ATOMS[3*atoms+1],&ATOMS[3*atoms+2]);

    if(strstr(atom_id,"CA")!=NULL || (strstr(firstWord,"HETATM")!=NULL && HETERO))
      {
	isCa[atoms]=1;
	CA_atoms++;
      }
    else
      isCa[atoms]=0;
   

    if(strstr(firstWord,"ATOM")!=NULL || (strstr(firstWord,"HETATM")!=NULL && HETERO))
      {
	
	if(ATOMS[3*atoms]<min[0])
	  min[0]=ATOMS[3*atoms];
	if(ATOMS[3*atoms+1]<min[1])
	  min[1]=ATOMS[3*atoms];    
	if(ATOMS[3*atoms+2]<min[2])
	  min[2]=ATOMS[3*atoms];
	
	if(ATOMS[3*atoms]>max[0])
	  max[0]=ATOMS[3*atoms];
	if(ATOMS[3*atoms+1]>max[1])
	  max[1]=ATOMS[3*atoms];    
	if(ATOMS[3*atoms+2]>max[2])
	  max[2]=ATOMS[3*atoms];
	
	atoms++;
      }
    }
    }
  }
  }  
}



sprintf(xyz_name,"%s.xyz",name);
xyz=fopen(xyz_name,"w");
printf("\ncreating xyz-file: %s\n",xyz_name);

fprintf(xyz,"                \n");

if(!CALPHA)
  fprintf(xyz,"2.0 2.0\n");
else
   fprintf(xyz,"4.0 4.0\n");

for(i=0;i<atoms;i++)
{
  if(!CALPHA || isCa[i])
    fprintf(xyz,"C%i %8.3f  %8.3f %8.3f\n",
	    i,
	    ATOMS[3*i],
	    ATOMS[3*i+1],ATOMS[3*i+2]);
}

fseek(xyz,0,SEEK_SET);
if(!CALPHA)
  fprintf(xyz,"%i",atoms);
else
{
  fprintf(xyz,"%i",CA_atoms);
}
fclose(xyz);








RG=0.0;

for(co=0;co<3;co++)
{
  if(max[co]-min[co]>RG)
    RG=max[co]-min[co];
}



/*ATOMS  = (float *)calloc((CHAIN_RES*15+number_o_nucl_acid_atoms+num_o_het_atoms)*3,sizeof(float));*/
distHist=(int *)calloc((int)(RG/binW)*5,sizeof(int));
nbins=5*(int)(RG/binW);

sprintf(saxs_name,"saxs_%s.dat",name);
printf("creating saxs-data file: %s\n",saxs_name);
saxs=fopen(saxs_name,"w");



n_o_ATOMS=atoms;

printf(" Number of Atoms :  %i\n",n_o_ATOMS);



 for(i=0;i<n_o_ATOMS;i++)
  {
    for(j=i+1;j<n_o_ATOMS;j++)
    {
      d=distance(&ATOMS[3*i],&ATOMS[3*j]);
      if((int)(d/binW)>=nbins)
      {
        printf("\n\n!!! check bin size !!!\n");
      }
      distHist[(int)(d/binW)]+=1;
    }
  }


s=0.0;
ds=0.001;
TwoPI=2.0*M_PI;
first=1;

while(s<0.06)
{
  sum=0.0;
  
  for(i=1;i<nbins;i++)
  {
      if(i>0)
      {
        d=(float)i*binW;
        arg=TwoPI*s*d;
        if((int)(1000.0*s)>0)
          sum+=(float)distHist[i]*sin(arg)/arg;
        else
          sum+=(float)distHist[i];
      }
      else
        sum+=distHist[i];
       
    
  }
 
  
  
  y=(float)n_o_ATOMS+2.0*sum;
  
  if(first)
    first_value=y;
  first=0;
  
  
  fprintf(saxs,"%f %f\n",s,y/first_value);

  s+=ds;
  
}





}




/*---------------------------------*/
 float distance_2(float *A,float *B)
/*---------------------------------*/
{
 return( ( (A[0]-B[0])*(A[0]-B[0])+
           (A[1]-B[1])*(A[1]-B[1])+
           (A[2]-B[2])*(A[2]-B[2])
         )
        );
}








/*---------------------------*/
  main(int argc ,char **argv)
/*---------------------------*/
{
  char   letter,*Name, name1[100], name2[100],aa,line[300],character,pdb_id[150],xyz_name[200],*p,
    saxs_name[200],
       Path1[230],Path2[230],*output,options[130],string[150],*word,word2[10];

int   i,j,k,dist,coordinate,res,res1,res2,FLAG,ANA,n_o_positions,coord,kc,
      ENDE,aa_n,chain,sub,dot,atom,AtoM ,atom2;
float t,Distance,dist_value,CUTOFF,closest,*point,point1[3],center_o_sc_2[3],vector[3],position[3],
      mean,distance(float *, float*),distance_2(float *, float*),center_o_sc[3],
      fraction_helix,fraction_sheet,fraction_PII,gyr;  
 
FILE *DIST_CORR,*out_g;
 



if(argc<3) 
  {
    printf("\npdb2xyz_saxs (D.Walther 1999)\nusage: command <pdb_file> C -out <out_name> [-het] [-ca]\n\n");
    printf("\tC = chainID, '_'-take all chains, 'A'-take chain A only\n");
    printf("\t\t!!chainID has to be specified, even if it is a single chain protein (then '_')\n");
    printf("\tout_name = write output to files containing <out_name> as name, default is test\n");
    printf("\t-het (optional) - include hetero atoms in both saxs profile and xyz-output\n");
    printf("\t-ca (optional) - write CAlpha atoms only to xyz-file\n\n");
    printf("NOTE: first argument has to be the protein file, second arg the chain identifier !\n");
    printf("example: pdb2xyz_saxs pdb1mbo.ent _ -out test -het\n");
    exit(0);
  }

sprintf(options,"%s ",argv[1]);
for(i=2;i<argc;i++) sprintf(options,"%s %s ",options,argv[i]);


sprintf(options,"%s -a",options);



 

 sprintf(title,"%s_%s",argv[1],argv[2]);
 chain_id= *argv[2];
 
 sprintf(pdb_name,"%s",argv[1]);
 


 i=strlen(pdb_name); 

 if(strstr(options,"-ca"))
   CALPHA=1;
 else
   CALPHA=0;

 if(strstr(options,"-het"))
   HETERO=1;
 else
   HETERO=0;

if(p=strstr(options,"-out "))
{
  sscanf(p+5,"%s",saxs_name);
  SAXS_DISTHIST(pdb_name,saxs_name);
}
else
  SAXS_DISTHIST(pdb_name,"test");

 
}






































