# define X  0   /* coordinates */
# define Y  1
# define Z  2




/*-------------------------------*/
 float VECTOR_ABS(float *vector)
/*-------------------------------*/
{

 return(sqrt(vector[0]*vector[0]+
             vector[1]*vector[1]+
             vector[2]*vector[2]
             )
        );

}

/*-------------------------------*/
 void NORM_VECTOR(float *vector)
/*-------------------------------*/
{ float absolute;
  int coordinate;

    absolute=VECTOR_ABS(vector);
    if(absolute>0.0)
      {
	for(coordinate=X;coordinate<=Z;coordinate++)
	  vector[coordinate]/=absolute;
      }
}

/*---------------------------------------------------*/
  void NORM_VECTOR_n_components(float *vector,int dim)
/*---------------------------------------------------*/
 { float absolute;
   int coordinate;
 
     absolute=0.0;
     for(coordinate=0;coordinate<dim;coordinate++)
       absolute+=vector[coordinate]*vector[coordinate];
     absolute=sqrt(absolute);
     
     if(absolute>0.0)
       {
       for(coordinate=0;coordinate<dim;coordinate++)
         vector[coordinate]/=absolute;
       }
 }
 


/*----------------------------------------------------*/
 void SCALAR_TIMES_VECTOR(float scalar, float *vector)
/*----------------------------------------------------*/
{ vector[0]*=scalar;
  vector[1]*=scalar;
  vector[2]*=scalar;
}



/*-----------------------------------------------*/
 float *VECTOR_PRODUCT(float *t1, float *t2)
/*-----------------------------------------------*/
{
 static float CROSS[3];
 float AX,AY,AZ, BX,BY,BZ;

 AX= t1[X];  AY= t1[Y];  AZ= t1[Z];
 BX= t2[X];  BY= t2[Y];  BZ= t2[Z];

 CROSS[X]=AY*BZ-AZ*BY;
 CROSS[Y]=AZ*BX-AX*BZ;
 CROSS[Z]=AX*BY-AY*BX;

return(CROSS);
}


/*------------------------------------------*/
 float SCALAR_PRODUCT(float *t1, float *t2)
/*------------------------------------------*/
{
 float DOT,
       AX,AY,AZ, BX,BY,BZ;

 AX= *t1; AY= *(t1+1); AZ= *(t1+2);
 BX= *t2; BY= *(t2+1); BZ= *(t2+2);

 DOT=AX*BX + AY*BY + AZ*BZ;

 return(DOT);
}


/*------------------------------------------*/
 float DOT_PRODUCT(float *t1, float *t2,int n)
/*------------------------------------------*/
{
 float DOT=0.0;

 int i;


 for(i=0;i<n;i++)
   DOT+=t1[i]*t2[i];
 
 return(DOT);
}




/*--------------------------------------------------------------------*/
 float Angle_between_lines(float *vector1, float *vector2)
/*--------------------------------------------------------------------*/
{ float value,A,B;

 if((A=VECTOR_ABS(vector1))>0.0 && (B=VECTOR_ABS(vector2))>0.0)
 {
   value=SCALAR_PRODUCT(vector1,vector2)/A/B;
 }
 if(fabs(value)>1.0) value=value/fabs(value);
 return(acos(value));
 
}




/*------------------------------------------------------------------------------*/
 float Oriented_Angle_between_vectors(float *vector1, float *vector2 , float *ref)
/*------------------------------------------------------------------------------*/
{

 float point3[3],point4[3],angle,orig[3],tmp_v[3];
 int coordinate,i;
 float dihedral(float *,float *,float *,float *),*p, 
       Angle_between_lines(float *,float *);


 orig[0]=0.0;
 orig[1]=0.0;
 orig[2]=0.0;



 p=VECTOR_PRODUCT(vector1,vector2);
 for(i=0;i<3;i++)
   tmp_v[i]=p[i];


 if(Angle_between_lines(tmp_v,ref)>M_PI/2.0)
   {
      for(coordinate=X;coordinate<=Z;coordinate++)
	p[coordinate]=-p[coordinate];
   }

 for(coordinate=X;coordinate<=Z;coordinate++)
   {
     ref[coordinate]=p[coordinate];
   }  

 for(coordinate=X;coordinate<=Z;coordinate++)
   point3[coordinate]=ref[coordinate];
 
 for(coordinate=X;coordinate<=Z;coordinate++)
   point4[coordinate]=point3[coordinate]+vector2[coordinate];
 
 angle=dihedral(vector1,orig,point3,point4);

 return(angle);


}






/*---------------------------------------------------------------------------*/
 float angle_from_points(float *point1, float *point2, float *point3)
/*---------------------------------------------------------------------------*/
{ float value,vector1[3],vector2[3];
  float Angle_between_lines(float *vector1, float *vector2);

 vector1[0]=point1[0]-point2[0];
 vector1[1]=point1[1]-point2[1];
 vector1[2]=point1[2]-point2[2];

 vector2[0]=point3[0]-point2[0];
 vector2[1]=point3[1]-point2[1];
 vector2[2]=point3[2]-point2[2];

  


 value= Angle_between_lines(vector1,vector2);
 return(value);
 
}





/*-------------------------------------------------------------------------------*/
 float dihedral(float *point1,float *point2,float *point3,float *point4)
/*-------------------------------------------------------------------------------*/
{ float vector[3][3],new_coord[3][3],*p,
        temp_vec1[3],temp_vec2[3],A,
        temp_vec1p[3],temp_vec2p[3],temp_vec3p[3],omega;
  int i;

  vector[0][X]=point1[X]-point2[X];
  vector[0][Y]=point1[Y]-point2[Y];
  vector[0][Z]=point1[Z]-point2[Z];

  vector[1][X]=point3[X]-point2[X];
  vector[1][Y]=point3[Y]-point2[Y];
  vector[1][Z]=point3[Z]-point2[Z];
  
  vector[2][X]=point4[X]-point3[X];
  vector[2][Y]=point4[Y]-point3[Y];
  vector[2][Z]=point4[Z]-point3[Z];

  NORM_VECTOR(vector[0]);
  NORM_VECTOR(vector[1]);
  NORM_VECTOR(vector[2]);

  p=VECTOR_PRODUCT(vector[0],vector[1]);
  new_coord[Y][X]=p[X];
  new_coord[Y][Y]=p[Y]; 
  new_coord[Y][Z]=p[Z];
 
  p=VECTOR_PRODUCT(vector[1],new_coord[Y]);

  new_coord[Z][X]=p[X];
  new_coord[Z][Y]=p[Y]; 
  new_coord[Z][Z]=p[Z];

  new_coord[X][X]= vector[0][X];
  new_coord[X][Y]= vector[0][Y]; 
  new_coord[X][Z]= vector[0][Z];


  NORM_VECTOR(new_coord[X]);
  NORM_VECTOR(new_coord[Y]);
  NORM_VECTOR(new_coord[Z]);


	    temp_vec1[X]=SCALAR_PRODUCT(vector[0],
                                        new_coord[X]);
	    temp_vec2[X]=SCALAR_PRODUCT(vector[2],
                                        new_coord[X]);

	    temp_vec1[Y]=SCALAR_PRODUCT(vector[0],
                                        new_coord[Y]);
	    temp_vec2[Y]=SCALAR_PRODUCT(vector[2],
                                        new_coord[Y]);

	    temp_vec1[Z]=SCALAR_PRODUCT(vector[0],
                                        new_coord[Z]);
	    temp_vec2[Z]=SCALAR_PRODUCT(vector[2],
                                        new_coord[Z]);

	    /* projection vector onto Y-Z plane */                  

	    temp_vec1p[Y]=temp_vec1[Y];
	    temp_vec2p[Y]=temp_vec2[Y];
	    temp_vec1p[Z]=temp_vec1[Z];
	    temp_vec2p[Z]=temp_vec2[Z];
	    temp_vec1p[X]=0.0;
	    temp_vec2p[X]=0.0;

	    
            omega=Angle_between_lines(temp_vec1p,temp_vec2p);
	    temp_vec3p[X]=0.0;
	    A=M_PI/2.0;
	    temp_vec3p[Y]=temp_vec1[Y]*cos(A)-temp_vec1[Z]*sin(A);
	    temp_vec3p[Z]=temp_vec1[Y]*sin(A)+temp_vec1[Z]*cos(A);

	    if(Angle_between_lines(temp_vec3p,temp_vec2p)>M_PI/2.0)
	    omega*=(-1.0);
            omega*=360.0/(2.0*M_PI);

 
 
return(omega);


}

/*------------------------------------------*/
 float distance(float *point1, float *point2)
/*------------------------------------------*/
{
 return(sqrt( (point2[0]-point1[0])*(point2[0]-point1[0])+
              (point2[1]-point1[1])*(point2[1]-point1[1])+
              (point2[2]-point1[2])*(point2[2]-point1[2])));
 
}


/*-------------------------------------------------------------------------------*/
 float global_dihedral(float *point1,float *point2,float *point3,float *point4,
                       float *a1, float *a2, float *d)
/*-------------------------------------------------------------------------------*/
{
  float *p,cross_product[3],new_point1[3],new_point2[3],new_point3[3],
    new_point4[3],t1=0.0,t2=0.0,dist,dist_test,length1,length2,angle1,angle2,
    vector1[3],vector2[3],vector_abs,q_vec[3],point_diff[3];
  int co;
  

  for(co=0;co<3;co++)
  {
    vector1[co]=point1[co]-point2[co];
    vector2[co]=point4[co]-point3[co];
  }

  length1=VECTOR_ABS(vector1);
  length2=VECTOR_ABS(vector2);
  
  NORM_VECTOR(vector1);
  NORM_VECTOR(vector2);


   
  p=VECTOR_PRODUCT(vector1,vector2);
  cross_product[0]=p[0];
  cross_product[1]=p[1];
  cross_product[2]=p[2];

  
  
  Again:
  
  for(co=0;co<3;co++)
    point_diff[co]=point2[co]-point3[co];

  dist=fabs(SCALAR_PRODUCT(point_diff,cross_product))/VECTOR_ABS(cross_product);

  
  

  vector_abs=VECTOR_ABS(cross_product);
  
  for(co=0;co<3;co++)
    q_vec[co]=dist*cross_product[co]/vector_abs;


  if(fabs(vector1[Y])<0.00001)
    printf("Error in global dihedral angle %f  !!!\n",vector1[Y]);
  
  
  
  t2=(point3[X]-q_vec[X]-point2[X]-
      (point3[Y]-q_vec[Y]-point2[Y])
      *vector1[X]/vector1[Y])/
    
    (vector2[Y]/vector1[Y]*
     vector1[X]-vector2[X]);

  
  t1=(point3[Y]+t2*vector2[Y]-
      q_vec[Y]-point2[Y])/vector1[Y];
   

/*
  for(co=0;co<3;co++)
    printf("%f %f   %f  %f\n",t1,t2,t2*vector2[co]+point3[co]+q_vec[co],
           t1*vector1[co]+point2[co]);

           */
  

  
 
    
  for(co=0;co<3;co++)
  {
    new_point1[co]= t1*vector1[co]+point1[co];
    new_point2[co]= t1*vector1[co]+point2[co];
    new_point3[co]= t2*vector2[co]+point3[co];
    new_point4[co]= t2*vector2[co]+point4[co];
  }

  dist_test=distance(new_point2,new_point3);


 
  if(dist_test-dist>0.001)
  {
    for(co=0;co<3;co++)
    {
      cross_product[co]*=-1.0;
    }
    goto Again;
    
  }


  angle1=180.0/M_PI*angle_from_points(point1,new_point2,point2);
  angle2=180.0/M_PI*angle_from_points(point3,new_point3,point4);


  
  
  
/*
  printf("%f %f %f    %f %f\n",dist,distance(new_point2,new_point3),
         distance(point2,point3),
         180.0/M_PI*angle_from_points(new_point1,new_point2,new_point3),
         180.0/M_PI*angle_from_points(new_point2,new_point3,new_point4));
         */

  *a1=angle1;
  *a2=angle2;
  *d=dist;
  
 
  return(dihedral(new_point1,new_point2,new_point3,new_point4));

  
}















