# include <math.h>

/*
# include "/home/cornelius/walther/argos1/C/include/vector.c"
# include "/home/cornelius/walther/argos1/C/include/rotate_2.c"
*/


# ifndef  RECIPE
 # include "nrutil.c"
 # include "jacobi.c"
 # include "eigsrt.c"
 # define  RECIPE TRUE
# endif


/* returns the root mean square difference between two sets of positions 
   see Goodfellow JM, Moss DS  "Computer Modelling of Biomolecular Processes" 
   p 11-
   ELLIS HORWOOD LIMITED, 1992

   NOTE: this routine calculates the rmsd of two conformations
   of the same sequential object; i.e. the assignments of the pairswise 
   positional relations are obvious */

/* returns rmsd; angle, translation, and rotation are filled*/


/*-----------------------------------------------------------------------*/
  float superimpose(float *positions1,
	     float *positions2,
             int n_o_positions,
             float *Angle, float *trans1, float *trans2, float *rotation_axis)
/*-----------------------------------------------------------------------*/
{
 float x,y,z,
       eigenvalues[5],**eigenvectors,max_d,dn,
   m[3],p[3],center1[3],center2[3],angle,
       **tensor,rot_axis[3];

 int i,*indx,nrot,j;
 float result_vector[8],sin_angle_half;
 


 
 tensor=(float **)malloc((unsigned)5*sizeof(float *));
 eigenvectors =(float **)malloc((unsigned)5*sizeof(float *));
 for(i=0;i<5;i++) {tensor[i]=(float *)malloc((unsigned)5*sizeof(float));
                   eigenvectors[i]=(float *)calloc(5,sizeof(float));
 }
 
 
 for(i=1;i<5;i++)
   {  for(j=1;j<5;j++) tensor[i][j]=0.0; }






 for(i=0;i<3;i++) {center1[i]=0.0; center2[i]=0.0;}

 for(i=0;i<n_o_positions;i++)
  {for(j=0;j<3;j++) {center1[j]+=positions1[3*i+j]; 
                     center2[j]+=positions2[3*i+j];
                    }
  }

 for(i=0;i<3;i++) 
   {center1[i]/=(float)n_o_positions; 
    center2[i]/=(float)n_o_positions;
   }
 

for(i=0;i<n_o_positions;i++)
  {
    for(j=0;j<3;j++)
    {
      positions1[3*i+j]-=center1[j];
      positions2[3*i+j]-=center2[j];
    }
  }


for(i=0;i<n_o_positions;i++)
  {
   
   for(j=0;j<3;j++) 
     { m[j]=positions1[3*i+j]-(positions2[3*i+j]);
       p[j]=positions1[3*i+j]+(positions2[3*i+j]);
     }

       tensor[1][1]+=m[0]*m[0] + m[1]*m[1] + m[2]*m[2];
       tensor[2][2]+=m[0]*m[0] + p[1]*p[1] + p[2]*p[2];
       tensor[3][3]+=p[0]*p[0] + m[1]*m[1] + p[2]*p[2];
       tensor[4][4]+=p[0]*p[0] + p[1]*p[1] + m[2]*m[2];

       tensor[1][2]+=p[1]*m[2]-m[1]*p[2];
       
       tensor[1][3]+=m[0]*p[2]-p[0]*m[2];

       tensor[1][4]+=p[0]*m[1]-m[0]*p[1];

       tensor[2][3]+=m[0]*m[1]-p[0]*p[1];

       tensor[2][4]+=m[0]*m[2]-p[0]*p[2];

       tensor[3][4]+=m[1]*m[2]-p[1]*p[2]; 
       


  }

       tensor[2][1]=tensor[1][2];
       tensor[3][2]=tensor[2][3]; 
       tensor[3][1]=tensor[1][3];
       tensor[4][1]=tensor[1][4];
       tensor[4][2]=tensor[2][4];
       tensor[4][3]=tensor[3][4]; 



jacobi(tensor,4,eigenvalues,eigenvectors,&nrot);
eigsrt(eigenvalues,eigenvectors,4);


/* get angle */
NORM_VECTOR_n_components(&eigenvectors[4][1],4);
angle=2.0*acos(eigenvectors[1][4]);

/* get rot axis */
sin_angle_half=sin(angle/2.0);

rot_axis[0]=eigenvectors[2][4]/sin_angle_half;
rot_axis[1]=eigenvectors[3][4]/sin_angle_half;
rot_axis[2]=eigenvectors[4][4]/sin_angle_half;

/* beware of the column - row priority */

for(i=0;i<n_o_positions;i++)
  {
    for(j=0;j<3;j++)
    {
      positions1[3*i+j]+=center1[j];
      positions2[3*i+j]+=center2[j];
    }
  }


Angle[0]=angle;
for(i=0;i<3;i++)
{
  trans1[i]=-center1[i];
  trans2[i]=-center2[i];
  rotation_axis[i]=rot_axis[i];
}

return(sqrt(eigenvalues[4]/(float)n_o_positions));


}


















































